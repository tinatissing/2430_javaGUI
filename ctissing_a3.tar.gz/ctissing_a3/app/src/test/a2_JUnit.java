package eStoreSearch;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.PrintWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class testApp {
  @Test public void testBook() {
    String testID = "123456";
    String testDes = "hello world";
    int testYear = 2020;
    String testPrice = "0.0";
    String testAuthor = "Christina Tissington";
    String testPublisher = "CIS2430 Inc";
    Book b = new Book( testID, testDes, testYear, testPrice, testAuthor, testPublisher );
      assertEquals( testID, b.getProductID() );
      assertEquals( testDes, b.getDescription() );
      assertEquals( testYear, b.getYear() );
      assertEquals( testPrice, b.getPrice() );
      assertEquals( testAuthor, b.getAuthor() );
      assertEquals( testPublisher, b.getPub() );
  }

  @Test public void testElectronic() {
    String testID = "123456";
    String testDes = "hello world";
    int testYear = 2020;
    String testPrice = "0.0";
    String testMaker = "Christina Tissington";
    Electronic e = new Electronics( testID, testDes, testYear, testPrice, testMaker );
      assertEquals( testID, b.getProductID() );
      assertEquals( testDes, b.getDescription() );
      assertEquals( testYear, b.getYear() );
      assertEquals( testPrice, b.getPrice() );
      assertEquals( testMaker, b.getMaker() );
  }

  @Test public void testFileOpen() {
    App testApp = new App();
    String legalName = "legal.txt";
    String illegalName = "illegal.txt";
    Scanner readFile = new Scanner( System.in );
      assertEquals( true, testApp.openFile( readFile, legalName) );
      assertEquals( false, testApp.openFile( readFile, illegalName) );
  }
}
